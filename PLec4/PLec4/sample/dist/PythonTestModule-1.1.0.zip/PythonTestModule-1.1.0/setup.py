from distutils.core import setup

setup(
    name = "PythonTestModule",
    version = "1.1.0",
    py_modules = ["printData"],
    author ="kojihae",
    author_email ="minimind@naver.com",
    url = "http://www.minimind.com",
    description="Test Module",
    )